# 0110225082_Ryuzan Zachry Maliq_CV

A Pen created on CodePen.

Original URL: [https://codepen.io/Syafina-Audia/pen/QwyqvRZ](https://codepen.io/Syafina-Audia/pen/QwyqvRZ).

