# praktikum1

A Pen created on CodePen.

Original URL: [https://codepen.io/Syafina-Audia/pen/QwyqeMy](https://codepen.io/Syafina-Audia/pen/QwyqeMy).

